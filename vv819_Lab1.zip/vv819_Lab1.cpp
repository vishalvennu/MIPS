#include<iostream>
#include<string>
#include<vector>
#include<bitset>
#include<fstream>
using namespace std;
#define MemSize 256 // memory size, in reality, the memory size should be 2^32, but for this lab, for the space resaon, we keep it as this large number, but the memory is still 32-bit addressable.

struct IFStruct {
    bitset<32>  PC;
    bool        nop;
};

struct IDStruct {
    bitset<32>  Instr;
    bool        nop;
};

struct EXStruct {
    bitset<32>  Read_data1;
    bitset<32>  Read_data2;
    bitset<16>  Imm;
    bitset<5>   Rs;
    bitset<5>   Rt;
    bitset<5>   Wrt_reg_addr;
    bool        is_I_type;
    bool        rd_mem;
    bool        wrt_mem;
    bool        alu_op;     //1 for addu, lw, sw, 0 for subu
    bool        wrt_enable;
    bool        nop;
};

struct MEMStruct {
    bitset<32>  ALUresult;
    bitset<32>  Store_data;
    bitset<5>   Rs;
    bitset<5>   Rt;
    bitset<5>   Wrt_reg_addr;
    bool        rd_mem;
    bool        wrt_mem;
    bool        wrt_enable;
    bool        nop;
};

struct WBStruct {
    bitset<32>  Wrt_data;
    bitset<5>   Rs;
    bitset<5>   Rt;
    bitset<5>   Wrt_reg_addr;
    bool        wrt_enable;
    bool        nop;
};

struct stateStruct {
    IFStruct    IF;
    IDStruct    ID;
    EXStruct    EX;
    MEMStruct   MEM;
    WBStruct    WB;
};

class RF
{
    public:
        bitset<32> Reg_data;
     	RF()
    	{
			Registers.resize(32);
			Registers[0] = bitset<32> (0);
        }

        bitset<32> readRF(bitset<5> Reg_addr)
        {
            Reg_data = Registers[Reg_addr.to_ulong()];
            return Reg_data;
        }

        void writeRF(bitset<5> Reg_addr, bitset<32> Wrt_reg_data)
        {
            Registers[Reg_addr.to_ulong()] = Wrt_reg_data;
        }

		void outputRF()
		{
			ofstream rfout;
			rfout.open("RFresult.txt",std::ios_base::app);
			if (rfout.is_open())
			{
				rfout<<"State of RF:\t"<<endl;
				for (int j = 0; j<32; j++)
				{
					rfout << Registers[j]<<endl;
				}
			}
			else cout<<"Unable to open file";
			rfout.close();
		}

	private:
		vector<bitset<32> >Registers;
};

class INSMem
{
	public:
        bitset<32> Instruction;
        INSMem()
        {
			IMem.resize(MemSize);
            ifstream imem;
			string line;
			int i=0;
			imem.open("imem.txt");
			if (imem.is_open())
			{
				while (getline(imem,line))
				{
					IMem[i] = bitset<8>(line);
					i++;
				}
			}
            else cout<<"Unable to open file";
			imem.close();
		}

		bitset<32> readInstr(bitset<32> ReadAddress)
		{
			string insmem;
			insmem.append(IMem[ReadAddress.to_ulong()].to_string());
			insmem.append(IMem[ReadAddress.to_ulong()+1].to_string());
			insmem.append(IMem[ReadAddress.to_ulong()+2].to_string());
			insmem.append(IMem[ReadAddress.to_ulong()+3].to_string());
			Instruction = bitset<32>(insmem);		//read instruction memory
			return Instruction;
		}

    private:
        vector<bitset<8> > IMem;
};

class DataMem
{
    public:
        bitset<32> ReadData;
        DataMem()
        {
            DMem.resize(MemSize);
            ifstream dmem;
            string line;
            int i=0;
            dmem.open("dmem.txt");
            if (dmem.is_open())
            {
                while (getline(dmem,line))
                {
                    DMem[i] = bitset<8>(line);
                    i++;
                }
            }
            else cout<<"Unable to open file";
                dmem.close();
        }

        bitset<32> readDataMem(bitset<32> Address)
        {
			string datamem;
            datamem.append(DMem[Address.to_ulong()].to_string());
            datamem.append(DMem[Address.to_ulong()+1].to_string());
            datamem.append(DMem[Address.to_ulong()+2].to_string());
            datamem.append(DMem[Address.to_ulong()+3].to_string());
            ReadData = bitset<32>(datamem);		//read data memory
            return ReadData;
		}

        void writeDataMem(bitset<32> Address, bitset<32> WriteData)
        {
            DMem[Address.to_ulong()] = bitset<8>(WriteData.to_string().substr(0,8));
            DMem[Address.to_ulong()+1] = bitset<8>(WriteData.to_string().substr(8,8));
            DMem[Address.to_ulong()+2] = bitset<8>(WriteData.to_string().substr(16,8));
            DMem[Address.to_ulong()+3] = bitset<8>(WriteData.to_string().substr(24,8));
        }

        void outputDataMem()
        {
            ofstream dmemout;
            dmemout.open("dmemresult.txt");
            if (dmemout.is_open())
            {
                for (int j = 0; j< 1000; j++)
                {
                    dmemout << DMem[j]<<endl;
                }

            }
            else cout<<"Unable to open file";
            dmemout.close();
        }

    private:
		vector<bitset<8> > DMem;
};

void printState(stateStruct state, int cycle)
{
    ofstream printstate;
    printstate.open("stateresult.txt", std::ios_base::app);
    if (printstate.is_open())
    {
        printstate<<"State after executing cycle:\t"<<cycle<<endl;

        printstate<<"IF.PC:\t"<<state.IF.PC.to_ulong()<<endl;
        printstate<<"IF.nop:\t"<<state.IF.nop<<endl;

        printstate<<"ID.Instr:\t"<<state.ID.Instr<<endl;
        printstate<<"ID.nop:\t"<<state.ID.nop<<endl;

        printstate<<"EX.Read_data1:\t"<<state.EX.Read_data1<<endl;
        printstate<<"EX.Read_data2:\t"<<state.EX.Read_data2<<endl;
        printstate<<"EX.Imm:\t"<<state.EX.Imm<<endl;
        printstate<<"EX.Rs:\t"<<state.EX.Rs<<endl;
        printstate<<"EX.Rt:\t"<<state.EX.Rt<<endl;
        printstate<<"EX.Wrt_reg_addr:\t"<<state.EX.Wrt_reg_addr<<endl;
        printstate<<"EX.is_I_type:\t"<<state.EX.is_I_type<<endl;
        printstate<<"EX.rd_mem:\t"<<state.EX.rd_mem<<endl;
        printstate<<"EX.wrt_mem:\t"<<state.EX.wrt_mem<<endl;
        printstate<<"EX.alu_op:\t"<<state.EX.alu_op<<endl;
        printstate<<"EX.wrt_enable:\t"<<state.EX.wrt_enable<<endl;
        printstate<<"EX.nop:\t"<<state.EX.nop<<endl;

        printstate<<"MEM.ALUresult:\t"<<state.MEM.ALUresult<<endl;
        printstate<<"MEM.Store_data:\t"<<state.MEM.Store_data<<endl;
        printstate<<"MEM.Rs:\t"<<state.MEM.Rs<<endl;
        printstate<<"MEM.Rt:\t"<<state.MEM.Rt<<endl;
        printstate<<"MEM.Wrt_reg_addr:\t"<<state.MEM.Wrt_reg_addr<<endl;
        printstate<<"MEM.rd_mem:\t"<<state.MEM.rd_mem<<endl;
        printstate<<"MEM.wrt_mem:\t"<<state.MEM.wrt_mem<<endl;
        printstate<<"MEM.wrt_enable:\t"<<state.MEM.wrt_enable<<endl;
        printstate<<"MEM.nop:\t"<<state.MEM.nop<<endl;

        printstate<<"WB.Wrt_data:\t"<<state.WB.Wrt_data<<endl;
        printstate<<"WB.Rs:\t"<<state.WB.Rs<<endl;
        printstate<<"WB.Rt:\t"<<state.WB.Rt<<endl;
        printstate<<"WB.Wrt_reg_addr:\t"<<state.WB.Wrt_reg_addr<<endl;
        printstate<<"WB.wrt_enable:\t"<<state.WB.wrt_enable<<endl;
        printstate<<"WB.nop:\t"<<state.WB.nop<<endl;
    }
    else cout<<"Unable to open file";
    printstate.close();
}

bitset<6> getSixBits(bitset<32> Ins, int start, int end) {
	int i, j = 5;
	bitset<6> temp;
	for (i = start; i >= end; i--)
	{
		temp[j] = Ins[i];
		j--;
	}
	return temp;
}

bitset<5> getFiveBits(bitset<32> Ins, int start, int end) {
	int i, j = 4;
	bitset<5> temp;
	for (i = start; i >= end; i--)
	{
		temp[j] = Ins[i];
		j--;
	}
	return temp;
}

bitset<32> signExtend(bitset<16> Imm){
	int j;
	bitset<32> extend;
	for (j = 0; j < 16; j++){
		extend[j] = Imm[j];
		extend[j+16] = Imm[15];
	}
	return extend;
}

int main()
{

    RF myRF;
    INSMem myInsMem;
    DataMem myDataMem;
    int cycle = 0;
	stateStruct state;
    cout << "start"<< endl;

    // nop initialization
    state.IF.nop = false;
    state.ID.nop = true;
    state.EX.nop = true;
    state.MEM.nop = true;
    state.WB.nop = true;
    // PC initialization
    state.IF.PC = -4;

    while (1) {
        stateStruct newState;
        bitset<6> opcode;
        bitset<6> funct;

        /* --------------------- WB stage --------------------- */
        if (state.WB.nop == false){
            if (state.WB.wrt_enable == true){
                myRF.writeRF(state.WB.Wrt_reg_addr, state.WB.Wrt_data);
            }
        }

        /* --------------------- MEM stage --------------------- */
        if (state.MEM.nop == false){
            if (state.MEM.wrt_mem == true){
                //write to memory
                newState.WB.Rs = state.MEM.Rs;
                newState.WB.Rt = state.MEM.Rt;
                myDataMem.writeDataMem(state.MEM.ALUresult, state.MEM.Store_data);
                newState.WB.wrt_enable = state.MEM.wrt_enable;
            }
            else if (state.MEM.rd_mem == true){
                //read from memory
                newState.WB.Rs = state.MEM.Rs;
                newState.WB.Rt = state.MEM.Rt;
                newState.WB.Wrt_data = myDataMem.readDataMem(state.MEM.ALUresult);
                newState.WB.wrt_enable = state.MEM.wrt_enable;
                newState.WB.Wrt_reg_addr = state.MEM.Wrt_reg_addr;
            }
            else{
                //r-type
                newState.WB.Wrt_data = state.MEM.ALUresult;
                newState.WB.Rs = state.MEM.Rs;
                newState.WB.Rt = state.MEM.Rt;
                newState.WB.wrt_enable = state.MEM.wrt_enable;
                newState.WB.Wrt_reg_addr = state.MEM.Wrt_reg_addr;
            }
            newState.WB.nop = false;
        }

        /* --------------------- EX stage --------------------- */
        if (state.EX.nop == false){
            // r-type instruction
            if (state.EX.is_I_type == false){
                // addu
                if (state.EX.alu_op == true)
                    newState.MEM.ALUresult = state.EX.Read_data1.to_ulong() + state.EX.Read_data2.to_ulong();
                // subu
                else
                    newState.MEM.ALUresult = state.EX.Read_data1.to_ulong() - state.EX.Read_data2.to_ulong();
                newState.MEM.Rs = state.EX.Rs;
                newState.MEM.Rt = state.EX.Rt;
                newState.MEM.rd_mem = state.EX.rd_mem;
                newState.MEM.wrt_mem = state.EX.wrt_mem;
                newState.MEM.wrt_enable = state.EX.wrt_enable;
                newState.MEM.Wrt_reg_addr = state.EX.Wrt_reg_addr;
            }
            // i-type
            else if(state.EX.is_I_type == true){
                //lw
                if(state.EX.rd_mem == true){
                    newState.MEM.ALUresult = state.EX.Read_data1.to_ulong() + (signExtend(state.EX.Imm)).to_ulong();
                    newState.MEM.rd_mem = state.EX.rd_mem;
                    newState.MEM.wrt_mem = state.EX.wrt_mem;
                    newState.MEM.wrt_enable = state.EX.wrt_enable;
                    newState.MEM.Rs = state.EX.Rs;
                    newState.MEM.Rt = state.EX.Rt;
                    newState.MEM.Wrt_reg_addr = state.EX.Wrt_reg_addr;
                }
                //sw
                else if(state.EX.wrt_mem == true){
                    newState.MEM.ALUresult = state.EX.Read_data1.to_ulong() + (signExtend(state.EX.Imm)).to_ulong();
                    newState.MEM.rd_mem = state.EX.rd_mem;
                    newState.MEM.wrt_mem = state.EX.wrt_mem;
                    newState.MEM.wrt_enable = state.EX.wrt_enable;
                    newState.MEM.Rs = state.EX.Rs;
                    newState.MEM.Rt = state.EX.Rt;
                    newState.MEM.Store_data = state.EX.Read_data2;
                }
                else{

                }
            }
            newState.MEM.nop = false;
        }

        /* --------------------- ID stage --------------------- */
        // Set the EXStruct according to the instruction
        if(state.ID.nop == false){
            opcode = getSixBits(state.ID.Instr, 31, 26);
            cout << "opcode: " << opcode << endl;
            // r-type
            if(opcode == 0x00){
                newState.EX.is_I_type = false;
                newState.EX.rd_mem = false;
                newState.EX.wrt_mem = false;
                newState.EX.wrt_enable = true;
                newState.EX.Rs = getFiveBits(state.ID.Instr, 25, 20);
                //raw hazard
                // if previous instruction is r-type then check for ex-ex hazard
                if (state.EX.is_I_type == false){
                    if (newState.EX.Rs == newState.MEM.Wrt_reg_addr){
                            newState.EX.Read_data1 = newState.MEM.ALUresult;
                    }
                    else{
                        newState.EX.Read_data1 = myRF.readRF(newState.EX.Rs);
                    }
                }else{
                    //lw hazard

                    newState.EX.Read_data1 = myRF.readRF(newState.EX.Rs);
                }
                newState.EX.Rt = getFiveBits(state.ID.Instr, 20, 16);
                newState.EX.Read_data2 = myRF.readRF(newState.EX.Rt);
                newState.EX.Wrt_reg_addr = getFiveBits(state.ID.Instr, 15, 11);
                cout << state.ID.Instr[1]<< endl;
                // addu
                if (state.ID.Instr[1] == 0)
                    newState.EX.alu_op = true;
                // subu
                else
                    newState.EX.alu_op = false;
            }
            // i-type [lw]
            else if(opcode == 0x23){
                newState.EX.is_I_type = true;
                newState.EX.rd_mem = true;
                newState.EX.wrt_mem = false;
                newState.EX.wrt_enable = true;
                newState.EX.Rs = getFiveBits(state.ID.Instr, 25, 20);
                newState.EX.Read_data1 = myRF.readRF(newState.EX.Rs);
                newState.EX.Rt = getFiveBits(state.ID.Instr, 20, 16);
                for (int i = 0; i < 16; i++) {
                    newState.EX.Imm[i] = state.ID.Instr[i];
                }
                //offset
                //newState.EX.Read_data2 = signExtend(newState.EX.Imm);
                newState.EX.Wrt_reg_addr = getFiveBits(state.ID.Instr, 20, 16);
                // add
                newState.EX.alu_op = true;
            }
            //sw
            else if(opcode == 0x2B){
                newState.EX.is_I_type = true;
                newState.EX.rd_mem = false;
                newState.EX.wrt_mem = true;
                newState.EX.wrt_enable = false;
                newState.EX.Rs = getFiveBits(state.ID.Instr, 25, 20);
                newState.EX.Read_data1 = myRF.readRF(newState.EX.Rs);
                newState.EX.Rt = getFiveBits(state.ID.Instr, 20, 16);
                newState.EX.Read_data2 = myRF.readRF(newState.EX.Rt);
                for (int i = 0; i < 16; i++){
                    newState.EX.Imm[i] = state.ID.Instr[i];
                }
                // add
                newState.EX.alu_op = true;
            }
            else if(opcode == 0x04){
                newState.EX.is_I_type = true;
                newState.EX.rd_mem = false;
                newState.EX.wrt_mem = false;
                newState.EX.wrt_enable = false;
                newState.EX.Rs = getFiveBits(state.ID.Instr, 25, 20);
                newState.EX.Read_data1 = myRF.readRF(newState.EX.Rs);
                newState.EX.Rt = getFiveBits(state.ID.Instr, 20, 16);
                newState.EX.Read_data2 = myRF.readRF(newState.EX.Rt);
            }
            newState.EX.nop = false;
        }

        /* --------------------- IF stage --------------------- */
        //initialize
        if(state.IF.nop == false){
            newState.IF.PC = state.IF.PC.to_ulong() + 4;
            newState.ID.Instr = myInsMem.readInstr(newState.IF.PC);
            newState.IF.nop = false;
            newState.ID.nop = false;
        }
        //beq
        //else if(){

        //}
        cout << "PC: " << newState.IF.PC.to_ulong() << endl;



        if (state.IF.nop && state.ID.nop && state.EX.nop && state.MEM.nop && state.WB.nop)
            break;

        printState(newState, cycle); //print states after executing cycle 0, cycle 1, cycle 2 ...

        state = newState; /*The end of the cycle and updates the current state with the values calculated in this cycle */

        cycle++;
        cin.get();
    }

    myRF.outputRF(); // dump RF;
	myDataMem.outputDataMem(); // dump data mem

	return 0;
}
